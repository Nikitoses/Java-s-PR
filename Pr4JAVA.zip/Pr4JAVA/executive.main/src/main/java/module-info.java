module executive.main {
    requires order.storage;
    requires order.processing;
    requires javafaker;
}