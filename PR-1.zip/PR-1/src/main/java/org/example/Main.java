package org.example;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        // Створюємо кошик та історію замовлень
        Cart cart = new Cart();
        OrderHistory orderHistory = new OrderHistory();
        Scanner scanner = new Scanner(System.in);

        // Ініціалізуємо товари
        List<Product> products = new ArrayList<>();
        products.add(new Product(1, "Телевізор", "Електроніка", 25000));
        products.add(new Product(2, "Ноутбук", "Електроніка", 50000));
        products.add(new Product(3, "Книга", "Література", 500));
        products.add(new Product(4, "Смартфон", "Електроніка", 30000));
        products.add(new Product(5, "Холодильник", "Побутова техніка", 45000));

        // Виводимо список товарів при запуску програми
        System.out.println("Доступні товари:");
        for (Product product : products) {
            System.out.println(product);
        }

        // Основне меню програми
        while (true) {
            System.out.println("\nВиберіть дію:");
            System.out.println("1: Додати товар до кошика");
            System.out.println("2: Видалити товар з кошика");
            System.out.println("3: Показати кошик");
            System.out.println("4: Оформити замовлення");
            System.out.println("5: Історія замовлень");
            System.out.println("6: Пошук товару");
            System.out.println("0: Вихід");
            int option = scanner.nextInt();

            switch (option) {
                case 1 -> {
                    System.out.println("Введіть ID товару для додавання в кошик:");
                    int id = scanner.nextInt();
                    // Шукаємо товар за ID та додаємо його до кошика
                    Product productToAdd = findProductById(products, id);
                    if (productToAdd != null) {
                        cart.addProduct(productToAdd);
                        System.out.println("Товар додано до кошика: " + productToAdd);
                    } else {
                        System.out.println("Товар з таким ID не знайдено.");
                    }
                }
                case 2 -> {
                    System.out.println("Введіть ID товару для видалення з кошика:");
                    int id = scanner.nextInt();
                    cart.removeProductById(id);
                    System.out.println("Товар з ID " + id + " видалено з кошика.");
                }
                case 3 -> System.out.println("Товари в кошику: " + cart);
                case 4 -> {
                    if (cart.isEmpty()) {
                        System.out.println("Кошик порожній. Додайте товари перед оформленням замовлення.");
                    } else {
                        double totalPrice = cart.getProducts().stream().mapToDouble(Product::getPrice).sum();
                        Order order = new Order(cart.getProducts(), totalPrice);
                        orderHistory.addOrder(order);
                        System.out.println("Замовлення оформлено: " + order);
                        cart.clear();
                    }
                }
                case 5 -> orderHistory.printHistory();
                case 6 -> {
                    System.out.println("1: Пошук за назвою");
                    System.out.println("2: Пошук за категорією");
                    int searchOption = scanner.nextInt();
                    if (searchOption == 1) {
                        System.out.println("Введіть назву товару:");
                        String name = scanner.next();
                        System.out.println("Знайдені товари: " + cart.searchByName(name));
                    } else if (searchOption == 2) {
                        System.out.println("Введіть категорію товару:");
                        String category = scanner.next();
                        System.out.println("Знайдені товари: " + cart.searchByCategory(category));
                    }
                }
                case 0 -> {
                    System.out.println("Дякуємо за використання нашого магазину!");
                    return;
                }
                default -> System.out.println("Невідома опція. Спробуйте ще раз.");
            }
        }
    }

    // Метод для пошуку товару за ID
    private static Product findProductById(List<Product> products, int id) {
        for (Product product : products) {
            if (product.getId() == id) {
                return product;
            }
        }
        return null;
    }
}
