package org.example;

import lombok.Data;
import java.util.ArrayList;
import java.util.List;

@Data
public class Cart {
    private List<Product> products = new ArrayList<>();

    // Добавление продукта в корзину
    public void addProduct(Product product) {
        products.add(product);
    }

    // Удаление продукта из корзины по ID
    public void removeProductById(int id) {
        products.removeIf(product -> product.getId() == id);
    }

    // Поиск продукта по названию
    public List<Product> searchByName(String name) {
        List<Product> result = new ArrayList<>();
        for (Product product : products) {
            if (product.getName().equalsIgnoreCase(name)) {
                result.add(product);
            }
        }
        return result;
    }

    // Поиск продукта по категории
    public List<Product> searchByCategory(String category) {
        List<Product> result = new ArrayList<>();
        for (Product product : products) {
            if (product.getCategory().equalsIgnoreCase(category)) {
                result.add(product);
            }
        }
        return result;
    }

    // Очистка корзины
    public void clear() {
        products.clear();
    }

    public boolean isEmpty() {
        return products.isEmpty();
    }
}
