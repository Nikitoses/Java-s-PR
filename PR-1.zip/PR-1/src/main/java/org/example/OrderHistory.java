package org.example;

import lombok.Data;
import java.util.ArrayList;
import java.util.List;

@Data
public class OrderHistory {
    private List<Order> orderList = new ArrayList<>();

    // Добавление заказа в историю
    public void addOrder(Order order) {
        orderList.add(order);
    }

    // Печать истории заказов
    public void printHistory() {
        for (Order order : orderList) {
            System.out.println(order);
        }
    }
}
