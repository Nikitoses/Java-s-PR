package org.example;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import java.util.Arrays;
import java.util.List;

class TransactionAnalyzerTest {
    @Test
    public void testCalculateTotalBalance() {
        // Створення тестових даних
        Transaction transaction1 = new Transaction("2023-01-01", 100.0, "Дохід");
        Transaction transaction2 = new Transaction("2023-01-02", -50.0, "Витрата");
        Transaction transaction3 = new Transaction("2023-01-03", 150.0, "Дохід");
        List<Transaction> transactions = Arrays.asList(transaction1, transaction2, transaction3);


        // Виклик методу, який потрібно протестувати
        double result = TransactionAnalyzer.calculateTotalBalance(transactions);

        // Перевірка результату
        Assertions.assertEquals(200.0, result, "Розрахунок загального балансу неправильний");
    }

    @Test
    public void testCountTransactionsByMonth() {
        // Підготовка тестових даних
        Transaction transaction1 = new Transaction("01-02-2023", 50.0, "Дохід");
        Transaction transaction2 = new Transaction("15-02-2023", -20.0, "Витрата");
        Transaction transaction3 = new Transaction("05-03-2023", 100.0, "Дохід");
        List<Transaction> transactions = Arrays.asList(transaction1, transaction2, transaction3);


        int countFeb = TransactionAnalyzer.countTransactionsByMonth("02-2023", transactions);
        int countMar = TransactionAnalyzer.countTransactionsByMonth("03-2023", transactions);

        // Перевірка результатів
        Assertions.assertEquals(2, countFeb, "Кількість транзакцій за лютий неправильна");
        Assertions.assertEquals(1, countMar, "Кількість транзакцій за березень неправильна");
    }

    @Test
    public void testFindTopExpenses() {
        List<Transaction> transactions = Arrays.asList(
                new Transaction("2023-01-01", -100.0, "Витрата 1"),
                new Transaction("2023-01-02", -50.0, "Витрата 2"),
                new Transaction("2023-01-03", 150.0, "Дохід"),
                new Transaction("2023-01-04", -200.0, "Витрата 3"),
                new Transaction("2023-01-05", -300.0, "Витрата 4"),
                new Transaction("2023-01-06", -10.0, "Витрата 5"),
                new Transaction("2023-01-07", -25.0, "Витрата 6"),
                new Transaction("2023-01-08", -400.0, "Витрата 7"),
                new Transaction("2023-01-09", -5.0, "Витрата 8"),
                new Transaction("2023-01-10", -150.0, "Витрата 9"),
                new Transaction("2023-01-11", -60.0, "Витрата 10")
        );

        List<Transaction> topExpenses = TransactionAnalyzer.findTopExpenses(transactions);

        Assertions.assertEquals(10, topExpenses.size(), "Кількість витрат не відповідає очікуваній");

        Assertions.assertEquals(-400.0, topExpenses.get(0).getAmount());
        Assertions.assertEquals(-300.0, topExpenses.get(1).getAmount());
        Assertions.assertEquals(-200.0, topExpenses.get(2).getAmount());
        Assertions.assertEquals(-150.0, topExpenses.get(3).getAmount());
        Assertions.assertEquals(-100.0, topExpenses.get(4).getAmount());
        Assertions.assertEquals(-60.0, topExpenses.get(5).getAmount());
        Assertions.assertEquals(-50.0, topExpenses.get(6).getAmount());
        Assertions.assertEquals(-25.0, topExpenses.get(7).getAmount());
        Assertions.assertEquals(-10.0, topExpenses.get(8).getAmount());

    }
}


