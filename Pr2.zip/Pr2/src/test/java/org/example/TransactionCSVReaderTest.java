package org.example;

import org.junit.jupiter.api.Test;

import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.List;
import java.util.Random;
import java.text.SimpleDateFormat;
import java.util.Date;

import static org.junit.jupiter.api.Assertions.assertEquals;

class TransactionCSVReaderTest {

    private static final String TEST_CSV_FILE = "test_transactions.csv";
    private static final Random RANDOM = new Random();
    private static final SimpleDateFormat DATE_FORMAT = new SimpleDateFormat("yyyy-MM-dd");

    @Test
    void testReadTransactions() throws IOException {
        generateRandomTransactions(TEST_CSV_FILE, 10);

        List<Transaction> transactions = TransactionCSVReader.readTransactions(TEST_CSV_FILE);

        assertEquals(10, transactions.size(), "Transaction size should match");

        for (int i = 0; i < transactions.size(); i++) {
            Transaction transaction = transactions.get(i);
            String expectedDate = DATE_FORMAT.format(new Date());
            String expectedDescription = "Transaction " + (i + 1);
            double expectedAmount = RANDOM.nextDouble() * 1000;

            System.out.println("Transaction Date: " + transaction.getDate());
            System.out.println("Transaction Amount: " + transaction.getAmount());
            System.out.println("Transaction Description: " + transaction.getDescription());


        }

        Files.deleteIfExists(Paths.get(TEST_CSV_FILE));
    }

    private void generateRandomTransactions(String filePath, int numberOfTransactions) throws IOException {
        try (BufferedWriter writer = new BufferedWriter(new FileWriter(filePath))) {
            for (int i = 0; i < numberOfTransactions; i++) {
                String date = DATE_FORMAT.format(new Date());
                double amount = RANDOM.nextDouble() * 1000;
                String description = "Transaction " + (i + 1);
                writer.write(String.join(",", date, String.valueOf(amount), description));
                writer.newLine();
            }
        }
    }
}
