package org.example;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.List;
import java.util.Comparator;
import java.util.List;
import java.util.stream.Collectors;

abstract class TransactionAnalyzer {


    // Метод для розрахунку загального балансу
    public static double calculateTotalBalance(List<Transaction> transactions) {
        double balance = 0;
        for (Transaction transaction : transactions) {
            balance += transaction.getAmount();
        }
        return balance;
    }

    public static int countTransactionsByMonth(String monthYear,List<Transaction> transactions) {
        int count = 0;
        for (Transaction transaction : transactions) {
            LocalDate date = LocalDate.parse(transaction.getDate(),  DateTimeFormatter.ofPattern("dd-MM-yyyy"));
            String transactionMonthYear = date.format(DateTimeFormatter.ofPattern("MM-yyyy"));
            if (transactionMonthYear.equals(monthYear)) {
                count++;
            }
        }
        return count;
    }
    public static List<Transaction> findTopExpenses(List<Transaction> transactions) {
        return transactions.stream()
                .filter(t -> t.getAmount() < 0) // Вибірка лише витрат (від'ємні значення)
                .sorted(Comparator.comparing(Transaction::getAmount)) // Сортування за сумою
                .limit(10) // Обмеження результату першими 10 записами
                .collect(Collectors.toList()); // Збір результату в список
    }
    public static ExpenseReport findMinMaxExpenses(String startDate, String endDate, List<Transaction> transactions) {
        LocalDate start = LocalDate.parse(startDate, DateTimeFormatter.ofPattern("dd-MM-yyyy"));
        LocalDate end = LocalDate.parse(endDate, DateTimeFormatter.ofPattern("dd-MM-yyyy"));

        Transaction minExpense = null;
        Transaction maxExpense = null;

        for (Transaction transaction : transactions) {
            LocalDate transactionDate = LocalDate.parse(transaction.getDate(), DateTimeFormatter.ofPattern("dd-MM-yyyy"));
            if (transactionDate.isAfter(start) && transactionDate.isBefore(end) && transaction.getAmount() < 0) {
                if (minExpense == null || transaction.getAmount() < minExpense.getAmount()) {
                    minExpense = transaction;
                }
                if (maxExpense == null || transaction.getAmount() > maxExpense.getAmount()) {
                    maxExpense = transaction;
                }
            }
        }

        return new ExpenseReport(minExpense, maxExpense);
    }

    public static class ExpenseReport {
        private final Transaction minExpense;
        private final Transaction maxExpense;

        public ExpenseReport(Transaction minExpense, Transaction maxExpense) {
            this.minExpense = minExpense;
            this.maxExpense = maxExpense;
        }

        public Transaction getMinExpense() {
            return minExpense;
        }

        public Transaction getMaxExpense() {
            return maxExpense;
        }
    }
}


