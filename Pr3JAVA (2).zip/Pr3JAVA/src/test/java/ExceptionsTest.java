//package org.example;

import org.example.Calculator;
import org.example.InvalidInputException;
import org.junit.jupiter.api.Test;

import static org.example.Calculator.calculatePlus;
import static org.example.Calculator.calculateSqrt;
import static org.junit.jupiter.api.Assertions.*;

import java.util.InputMismatchException;
import java.util.Scanner;

class ExceptionsTest {

    @Test
    void testArithmeticException() {
        assertThrows(ArithmeticException.class, () -> {
            Calculator.calculateDivide(10, 0);
        });
    }

    @Test
    void testInvalidInputException() {
        assertThrows(InvalidInputException.class, () -> {
            double num = -1.0;
            calculateSqrt(num);
        });
    }

    @Test
    void testInputMismatchException() {
        assertThrows(InputMismatchException.class, () -> {
            Scanner scanner = new Scanner("a");
            try {
                double num = scanner.nextDouble();
                double num2 = scanner.nextDouble();
                calculatePlus(num, num2);
            } finally {
                scanner.close();
            }
        });
    }

}