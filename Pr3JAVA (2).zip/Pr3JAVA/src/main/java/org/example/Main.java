package org.example;

import java.util.InputMismatchException;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        boolean isRunning = true;

        System.out.println("Welcome to the enhanced Calculator!");

        while (isRunning) {
            try {
                System.out.println("Enter the first number:");
                double a = readDouble(scanner);

                System.out.println("Enter the second number:");
                double b = readDouble(scanner);

                System.out.println("Choose an operation (+, -, *, /, sqrt):");
                String operation = scanner.next();

                double result;
                switch (operation) {
                    case "+":
                        result = Calculator.add(a, b);
                        break;
                    case "-":
                        result = Calculator.subtract(a, b);
                        break;
                    case "*":
                        result = Calculator.multiply(a, b);
                        break;
                    case "/":
                        result = Calculator.divide(a, b);
                        break;
                    case "sqrt":
                        result = Calculator.sqrt(a);
                        break;
                    default:
                        System.out.println("Invalid operation. Please try again.");
                        continue;
                }

                System.out.println("Result: " + result);

            } catch (ArithmeticException e) {
                System.out.println("Error: " + e.getMessage());
            } catch (InvalidInputException e) {
                System.out.println("Error: " + e.getMessage());
            } catch (InputMismatchException e) {
                System.out.println("Error: Invalid input. Please enter a number.");
                scanner.next(); // Clear the invalid input
            } finally {
                System.out.println("Operation completed.");
                System.out.println("Do you want to perform another calculation? (y/n):");
                String response = scanner.next();
                if (response.equalsIgnoreCase("n")) {
                    isRunning = false;
                }
            }
        }

        System.out.println("Thank you for using the calculator. Goodbye!");
        scanner.close();
    }

    private static double readDouble(Scanner scanner) throws InputMismatchException {
        try {
            return scanner.nextDouble();
        } catch (InputMismatchException e) {
            throw new InputMismatchException("Invalid input: Please enter a number.");
        }
    }
}
